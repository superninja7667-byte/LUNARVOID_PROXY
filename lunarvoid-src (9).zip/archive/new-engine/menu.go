package engine

import (
	"archive/zip"
	"bytes"
	"embed"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
)

//go:embed all:pack
var packFiles embed.FS

type tab struct{ id, title, subtitle string }

// The in-game menu pack expects exactly this many tab buttons at the end of
// every form (see pack/ui/lunarvoid.json: "#form_button_length - 5").
var tabs = []tab{
	{"modules", "Modules", "Configure built-in client mods"},
	{"replay", "Replay Mod", "Record and play back your sessions"},
	{"skins", "Skins & packs", "Use your own skin and resource packs"},
	{"client", "Client settings", "How the LUNARVOID menu behaves"},
	{"help", "Help", "Commands and tips"},
}

type card struct {
	name, desc, kind, arg string
}

func cardsFor(tabID string) []card {
	switch tabID {
	case "replay":
		return []card{
			{"Recording", "Record with /.replay", "soon", ""},
			{"Playback", "Watch your clips", "soon", ""},
		}
	case "skins":
		return []card{
			{"Skins", "Pick your skin", "soon", ""},
			{"Resource packs", "Import .mcpack", "soon", ""},
		}
	case "client":
		return []card{
			{"Emote menu", "Menu on emote", "toggle", "emote"},
			{"Ping", "Latency", "toggle", "ping"},
			{"Battery", "Phone battery", "toggle", "battery"},
			{"Coordinates", "Your X, Y, Z", "toggle", "coordinates"},
		}
	case "help":
		return []card{
			{"/.menu", "Open this menu", "info", ""},
			{"/.help", "Show this help", "info", ""},
			{"/.replay", "Replay (soon)", "info", ""},
		}
	}
	return []card{
		{"Ping", "Latency", "toggle", "ping"},
		{"Battery", "Phone battery", "toggle", "battery"},
		{"Coordinates", "Your X, Y, Z", "toggle", "coordinates"},
		{"Replay recording", "Coming soon", "goto", "replay"},
		{"Replay playback", "Coming soon", "goto", "replay"},
		{"Emote menu", "Menu on emote", "toggle", "emote"},
		{"Skins & packs", "Coming soon", "goto", "skins"},
		{"Help", "Commands", "goto", "help"},
	}
}

// buildForm makes the JSON for a server form. Buttons are the cards first,
// then the tab buttons. Text prefixes tell the menu pack how to draw them:
// "on:" = card switched on, "tab:" / "tabon:" = sidebar tab (inactive / active).
func buildForm(tabID string, st settings) ([]byte, []card) {
	cur := tabs[0]
	for _, t := range tabs {
		if t.id == tabID {
			cur = t
		}
	}
	cards := cardsFor(cur.id)
	buttons := make([]map[string]string, 0, len(cards)+len(tabs))
	for _, cd := range cards {
		prefix, desc := "", cd.desc
		if cd.kind == "toggle" {
			if st.get(cd.arg) {
				prefix = "on:"
				desc += "  §aON"
			} else {
				desc += "  §cOFF"
			}
		}
		buttons = append(buttons, map[string]string{"text": prefix + "§l" + cd.name + "§r\n§7" + desc})
	}
	for _, t := range tabs {
		p := "tab:"
		if t.id == cur.id {
			p = "tabon:"
		}
		buttons = append(buttons, map[string]string{"text": p + t.title})
	}
	body, _ := json.Marshal(map[string]any{
		"type":    "form",
		"title":   "LUNARVOID",
		"content": "§l" + cur.title + "§r\n§7" + cur.subtitle,
		"buttons": buttons,
	})
	return body, cards
}

// writePack zips the menu resource pack into dir and returns its path.
func writePack(dir string) (string, error) {
	path := filepath.Join(dir, "lunarvoid-menu.mcpack")
	f, err := os.Create(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	zw := zip.NewWriter(f)
	add := func(name string, data []byte) error {
		w, err := zw.Create(name)
		if err != nil {
			return err
		}
		_, err = w.Write(data)
		return err
	}
	err = fs.WalkDir(packFiles, "pack", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		data, err := packFiles.ReadFile(p)
		if err != nil {
			return err
		}
		return add(strings.TrimPrefix(p, "pack/"), data)
	})
	if err != nil {
		return "", err
	}
	if err := add("textures/lunarvoid/pixel.png", pixelPNG()); err != nil {
		return "", err
	}
	if err := add("textures/lunarvoid/logo.png", logoPNG()); err != nil {
		return "", err
	}
	if err := zw.Close(); err != nil {
		return "", err
	}
	return path, nil
}

func pixelPNG() []byte {
	img := image.NewNRGBA(image.Rect(0, 0, 1, 1))
	img.SetNRGBA(0, 0, color.NRGBA{R: 255, G: 255, B: 255, A: 255})
	var b bytes.Buffer
	_ = png.Encode(&b, img)
	return b.Bytes()
}

// logoPNG draws the LUNARVOID mark: the same four-point shape as the app logo.
func logoPNG() []byte {
	const n = 64
	img := image.NewNRGBA(image.Rect(0, 0, n, n))
	poly := [][2]float64{{0, 0}, {40, 7.2}, {22, 40}, {12, 23.2}}
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			px, py := (float64(x)+0.5)*40/n, (float64(y)+0.5)*40/n
			if inside(poly, px, py) {
				t := (float64(x) + float64(y)) / (2 * n)
				img.SetNRGBA(x, y, color.NRGBA{R: uint8(97 - 89*t), G: uint8(232 - 113*t), B: 255, A: 255})
			}
		}
	}
	var b bytes.Buffer
	_ = png.Encode(&b, img)
	return b.Bytes()
}

func inside(poly [][2]float64, x, y float64) bool {
	in := false
	for i, j := 0, len(poly)-1; i < len(poly); j, i = i, i+1 {
		xi, yi, xj, yj := poly[i][0], poly[i][1], poly[j][0], poly[j][1]
		if (yi > y) != (yj > y) && x < (xj-xi)*(y-yi)/(yj-yi)+xi {
			in = !in
		}
	}
	return in
}
