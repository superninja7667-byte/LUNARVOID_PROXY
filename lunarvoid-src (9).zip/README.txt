LUNARVOID PROXY - source (build 5: two APKs to compare)

original/old-app.apk   your old app, untouched. Workflow APK 1 = this app + your v4 page, re-signed with your key.
app/                   APK 2 = the old engine (liblunarvoid50.so) inside new Android code
  lunarvoid.jks        fixed signing key. Keep your repository PRIVATE.
archive/new-engine/    the engine I wrote earlier (new in-game menu). Not built right now.
